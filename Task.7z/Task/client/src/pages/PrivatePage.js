import React from "react";

const PrivatePage = () => {
  return <div>Private Page</div>;
};

export default PrivatePage;
