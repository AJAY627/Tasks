const User = require("../model/user");
const { generateToken } = require("../utils/generateJsonWebToken");
const jwt = require("jsonwebtoken");
const { sendEmailWithNodemailer } = require("../utils/emialHelper");
const _ = require("lodash");

exports.activationAccount = (req, res) => {
  const { name, email, password } = req.body;
  User.findOne({ email: email.toLowerCase() }, (err, user) => {
    if (user) {
      return res.status(400).json({ error: "Email is already exist" });
    }
    const token = jwt.sign(
      { name, email, password },
      process.env.JWT_ACCOUNT_ACTIVATION,
      { expiresIn: "10m" }
    );

    const emailData = {
      from: process.env.EMAIL_FROM, // MAKE SURE THIS EMAIL IS YOUR GMAIL FOR WHICH YOU GENERATED APP PASSWORD
      to: email, // WHO SHOULD BE RECEIVING THIS EMAIL? IT SHOULD BE YOUR GMAIL
      subject: `Account activation link from ${process.env.APP_NAME}`,
      html: `
              <p>Please use the following link to activate your account :</p>
              <p>${process.env.CLIENT_URL}/account/activate/${token}</p>
              <hr />
              <p>This email may contain sensitive information</p>
              <small>More information please visit my website</small>
              <p>https://riyazportfolio.netlify.app/</p>
          `,
    };
    sendEmailWithNodemailer(req, res, emailData);
  });
};

exports.registration = async (req, res) => {
  const token = req.body.token;
  if (token) {
    jwt.verify(
      token,
      process.env.JWT_ACCOUNT_ACTIVATION,
      function (err, decoded) {
        if (err) {
          return res
            .status(400)
            .json({ error: "Expired link, Please siginUp again!" });
        }
        const { name, email, password } = jwt.decode(token);

        let user = new User({ name, email, password });

        user.save((err, success) => {
          if (err) {
            return res.status(400).json({ error: errorHandler(err) });
          }
          return res.json({ message: "Signup success! Please signin." });
        });
      }
    );
  } else {
    return res
      .status(400)
      .json({ message: "Something went wrong try again!!" });
  }
};

exports.signin = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && (await user.matchPassword(password))) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      token: generateToken(user._id),
    });
  } else {
    res.status(404).json({ error: "Invalid email and passwod" });
  }
};

exports.getProfile = async (req, res) => {
  const profile = await User.findById(req.user._id).exec();
  res.json(profile);
};

exports.forgotPassword = (req, res) => {
  const { email } = req.body;
  User.findOne({ email }, (err, user) => {
    if (err || !user) {
      return res
        .status(400)
        .json({ error: "Sorry, User does not exist in database" });
    }
    const token = jwt.sign({ _id: user._id }, process.env.JWT_RESET_PASSWORD, {
      expiresIn: "10m",
    });
    // send email to the  user

    const emailData = {
      from: process.env.EMAIL_FROM, // MAKE SURE THIS EMAIL IS YOUR GMAIL FOR WHICH YOU GENERATED APP PASSWORD
      to: email, // WHO SHOULD BE RECEIVING THIS EMAIL? IT SHOULD BE YOUR GMAIL
      subject: `Password reset link from ${process.env.APP_NAME}`,
      html: `
              <p>Please use the following link to reset your password :</p>
              <p>${process.env.CLIENT_URL}/password/reset/${token}</p>
              <hr />
              <p>This email may contain sensitive information</p>
              <small>More information please visit my website</small>
              <p>https://riyazportfolio.netlify.app/</p>
          `,
    };

    // populate the  db > user > resetPasswordLink
    return user.updateOne({ resetPasswordLink: token }, (err, success) => {
      if (err) {
        return res.status(400).json({ error: errorHandler(err) });
      } else {
        sendEmailWithNodemailer(req, res, emailData);
      }
    });
  });
};

exports.resetPassword = (req, res) => {
  const { resetPasswordLink, newPassword } = req.body;
  if (resetPasswordLink) {
    jwt.verify(
      resetPasswordLink,
      process.env.JWT_RESET_PASSWORD,
      function (err, decoded) {
        if (err) {
          return res
            .status(401)
            .json({ error: "Sorry, your link has been expired! Try again!" });
        }
        User.findOne({ resetPasswordLink }, (err, user) => {
          if (err || !user) {
            return res
              .status(401)
              .json({ error: "Sorry, Something went wrong" });
          }
          const updatedFields = {
            password: newPassword,
            resetPasswordLink: "",
          };
          user = _.extend(user, updatedFields);
          user.save((err, result) => {
            if (err) {
              return res.status(401).json({ error: errorHandler(err) });
            }
            res.json({
              message: "Great! Now you can login with updated passwor.",
            });
          });
        });
      }
    );
  }
};
