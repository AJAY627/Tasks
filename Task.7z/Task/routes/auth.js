const express = require("express");

const router = express.Router();

const { authCheck } = require("../middlewares/auth");

const {
  activationAccount,
  registration,
  signin,
  getProfile,
  forgotPassword,
  resetPassword,
} = require("../controllers/auth");

router.post("/account-activation", activationAccount);

router.post("/register", registration);
router.put("/reset-password", resetPassword);
router.put("/forget-password", forgotPassword);
router.post("/signin", signin);

router.get("/acccess", authCheck, getProfile);

module.exports = router;
