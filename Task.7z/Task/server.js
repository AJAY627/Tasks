const express = require("express");
const mongoose = require("mongoose");
const morgan = require("morgan");
const bodyParser = require("body-parser");
const cors = require("cors");
const { readdirSync } = require("fs");
require("dotenv").config();

//app
const app = express();

//database
mongoose
  .connect(process.env.DATABASE, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Database connected");
  })
  .catch((err) => {
    console.log("DB connection Error", err);
  });

// middleware
app.use(morgan("dev"));
app.use(bodyParser.json());
app.use(cors());


app.get('/', (req, res) => {
  res.send("Welcome")
})

// ROUTES MIDDLEWARE
readdirSync("./routes").map((route) =>
  app.use("/api", require("./routes/" + route))
);

const port = process.env.PORT || 8000;
app.listen(port, () => console.log(`Server running... ${port}`));
